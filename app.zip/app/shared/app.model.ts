export class Dier{
    
    constructor(
        public ras: string,
        public populatie: number,
        public valtOnderDierenbelasting: boolean){
    }
}