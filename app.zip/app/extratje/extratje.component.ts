import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-extratje',
  templateUrl: './extratje.component.html',
  styleUrls: ['./extratje.component.css']
})
export class ExtratjeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
