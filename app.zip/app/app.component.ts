import {Component,  OnInit} from '@angular/core';
import { Dier } from './shared/app.model';

@Component({
  // 1. Inside @Component Decorator.
  // Add component description/annotations here
  selector: 'hello-world',
  template: `
    <h1>Hello World!</h1>
    <h2>This is Angular</h2>
    <h3>{{naam}}'s huisdieren:</h3>
    <ul>
    <li *ngFor="let Dier of dierInfo"> 
      Ras: {{ Dier.ras}} -
      Populatie: {{ Dier.populatie }} -
      HuisdierenBelasting: {{Dier.valtOnderDierenbelasting}}</li>
    </ul>
    <div (click)= "handleClick(Dier.ras)"></div>
    
    <a href="http://angular.io" target="_blank">Angular Website</a>
  `
})

export class AppComponent implements OnInit {
  // 2. optional: add variables, constructor, class logic, etc. here

  steden! : string[];
  naam!: string;
  dierInfo!: Dier[];

  constructor() {
    this.steden = ['Rotterdam', 'Amersfoort', 'Apeldoorn']
    this.naam = 'Cecilia';
    this.dierInfo = [
      new Dier('hond', 200, true),
      new Dier('kat', 300, false),
      new Dier('lama', 1, false )
    ]

    handleClick
  }

  ngOnInit() {
    console.log('Hello World - Angular is running');
    //this.steden = ['Rotterdam', 'Amersfoort', 'Apeldoorn']
    this.naam = 'Cecilia';

  }

}
