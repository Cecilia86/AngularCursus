// Angular Modules
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

// Custom Components
import {AppComponent} from './app.component';
import { Component2Component } from './component2/component2.component';
import { ExtratjeComponent } from './extratje/extratje.component';

// Module declaration
@NgModule({
  imports: [BrowserModule],
  declarations: [AppComponent, Component2Component, ExtratjeComponent],
  bootstrap: [AppComponent]
})
export class AppModule {
}


